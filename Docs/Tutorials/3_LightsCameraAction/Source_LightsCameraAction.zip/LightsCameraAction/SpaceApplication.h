
#include "ExampleApplication.h"



class LightFlasher : public ControllerValue
{
protected:
	Light* mLight;
	Billboard* mBillboard;
	ColourValue mMaxColour;
	Real intensity;
public:
	LightFlasher(Light* light, Billboard* billboard, ColourValue maxColour)
	{
		mLight = light;
		mBillboard = billboard;
		mMaxColour = maxColour;
	}

	virtual Real  getValue (void)
	{
		return intensity;
	}

	virtual void  setValue (Real value)
	{
		intensity = value;

		ColourValue newColour;

		// Attenuate the brightness of the light
		newColour.r = mMaxColour.r * intensity;
		newColour.g = mMaxColour.g * intensity;
		newColour.b = mMaxColour.b * intensity;

		mLight->setDiffuseColour(newColour);
		mBillboard->setColour(newColour);
	}
};


class LightBlinker : public LightFlasher
{
protected:
	ColourValue mMinColour;
	Real mActivationLevel;
public:
	LightBlinker(Light* light, Billboard* billboard, ColourValue maxColour, ColourValue minColour, Real activationLevel) : LightFlasher(light, billboard, maxColour)
	{
		mMinColour = minColour;
		mActivationLevel = activationLevel;
	}

	virtual Real  getValue (void)
	{
		return intensity;
	}

	virtual void setValue(Real value)
	{
		intensity = value;


		if(value < mActivationLevel)
		{
			// Light is off
			mLight->setDiffuseColour(mMinColour);
			mBillboard->setColour(mMinColour);
		} else {
			// Light is blinking on
			mLight->setDiffuseColour(mMaxColour);
			mBillboard->setColour(mMaxColour);
		}
	}

};


class LightFlasherControllerFunction : public WaveformControllerFunction
{
public:
	LightFlasherControllerFunction(WaveformType wavetype, Real frequency, Real phase) : WaveformControllerFunction(wavetype, 0, frequency, phase, 1, true)
	{

	}
};




class CameraShaker : public ControllerValue<Real>
{
protected:
	Camera* mCamera;
	Vector3 mInitialPosition;
	Vector3 mShakeDirection;
	Real intensity;
public:
	CameraShaker(Camera* cam, Vector3 initialPosition, Vector3 shakeDirection)
	{
		mCamera = cam;
		mInitialPosition = initialPosition;
		mShakeDirection = shakeDirection;
	}

	virtual Real  getValue (void)
	{
		return intensity;
	}
	virtual void setValue(Real value)
	{
		intensity = value;
		Vector3 newPosition = mInitialPosition + (mShakeDirection * value);

		mCamera->setPosition(newPosition);
	}
};


class CameraShakerControllerFunction : public WaveformControllerFunction
{
public:
	CameraShakerControllerFunction(WaveformType wavetype, Real frequency, Real phase, Real magnitude) : WaveformControllerFunction(wavetype, 0, frequency, phase, magnitude, true)
	{

	}
};






class SpaceFrameListener : public ExampleFrameListener
{
protected:
	SceneNode* mShipNode;

public:
    SpaceFrameListener(RenderWindow* win, Camera* cam, SceneNode* shipNode) : ExampleFrameListener(win, cam)
    {
		mShipNode = shipNode;
    };

    bool frameStarted(const FrameEvent& evt)
    {
		// Move upto 80 units/second
		Real MoveFactor = 80.0 * evt.timeSinceLastFrame;

		// Copy the current state of the input devices
		mInputDevice->capture();

		// Move the ship node!
		if(mInputDevice->isKeyDown(Ogre::KC_UP))
		  mShipNode->translate(0.0, MoveFactor, 0.0);

		if(mInputDevice->isKeyDown(Ogre::KC_DOWN))
		  mShipNode->translate(0.0, -MoveFactor, 0.0);

		// Instead of moving the ship left and right, rotate it using yaw()
		if(mInputDevice->isKeyDown(Ogre::KC_LEFT))
		  mShipNode->yaw(MoveFactor);

		if(mInputDevice->isKeyDown(Ogre::KC_RIGHT))
		  mShipNode->yaw(-MoveFactor);

		return true;
    }
};


class SpaceCameraRotator : public ExampleFrameListener
{
protected:
	Camera* mCamera;
	SceneNode* mCentralNode;
	SceneNode* mRotatingNode;
	Vector3 mRotationAxis;
	Real mRotationSpeed;

public:
	SpaceCameraRotator(RenderWindow* win, Camera* cam, SceneNode* centralNode, Vector3 initialPosition) : ExampleFrameListener(win, cam)
	{
		mCamera = cam;
		mCentralNode = centralNode;
		mRotationAxis = Vector3::UNIT_Y;
		mRotationSpeed = 60.0;

		// Create a node to act as the central rotation point
		mRotatingNode = mCentralNode->createChild();

		mRotatingNode->attachCamera(mCamera);
		mCamera->moveRelative(initialPosition);
		mCamera->lookAt(0, 0, 0);
	}

	~SpaceCameraRotator()
	{
		delete mRotatingNode;
	}

    bool frameStarted(const FrameEvent& evt)
    {
		// Copy the current state of the input devices
		mInputDevice->capture();

		if(mInputDevice->isKeyDown(Ogre::KC_SPACE))
		  mRotatingNode->rotate(mRotationAxis, mRotationSpeed * evt.timeSinceLastFrame);		

		return true;
	}

};




class SpaceApplication : public ExampleApplication
{
protected:
    Entity* mShip;
	SceneNode* mShipNode;

	// The set of all the billboards used for the avionic lights
	BillboardSet* mLights;

	// Billboards
	Billboard* mRedLightBoard;
	Billboard* mBlueLightBoard;
	Billboard* mWhiteLightBoard;

	// Lights
	Light* mRedLight;
	Light* mBlueLight;
	Light* mWhiteLight;


	// Light flashers
	LightFlasher* mRedLightFlasher;
	LightFlasher* mBlueLightFlasher;
	LightFlasher* mWhiteLightFlasher;

	// Light controller functions
	LightFlasherControllerFunction* mRedLightControllerFunc;
	LightFlasherControllerFunction* mBlueLightControllerFunc;
	LightFlasherControllerFunction* mWhiteLightControllerFunc;

	// Light controllers
	Controller<Real>* mRedLightController;
	Controller<Real>* mBlueLightController;
	Controller<Real>* mWhiteLightController;

	void createScene(void)
    {
		// Set a very low level of ambient lighting
		mSceneMgr->setAmbientLight(ColourValue(0.2, 0.2, 0.2));

        // Use the "Space" skybox
        mSceneMgr->setSkyBox(true, "Examples/SpaceSkyBox");

		// Load "Razor", our space ship
		mShip = mSceneMgr->createEntity("razor", "razor.mesh");

		// Create a Scene Node and attach our ship to it
		mShipNode = mSceneMgr->getRootSceneNode()->createChild();
		mShipNode->attachObject(mShip);


		// First create the BillboardSet. This will define the materials for the billboards
		// in its set to use
		mLights = mSceneMgr->createBillboardSet("FlyingLights");
		mLights->setMaterialName("Examples/FlyingLightMaterial");
		mShipNode->attachObject(mLights);


		// Red light billboard, in "off" state
		Vector3 redLightPosition(78, -8, -70);
		mRedLightBoard = mLights->createBillboard(redLightPosition);
		mRedLightBoard->setColour(ColourValue::Black);


		// Blue light billboard, in "off" state
		Vector3 blueLightPosition(-90, -8, -70);
		mBlueLightBoard = mLights->createBillboard(blueLightPosition);
		mBlueLightBoard->setColour(ColourValue::Black);


		// White light billboard, in "off" state
		Vector3 whiteLightPosition(-4.5, 30, -80);
		mWhiteLightBoard = mLights->createBillboard(whiteLightPosition);
		mWhiteLightBoard->setColour(ColourValue::Black);


		// Red light, in "off" state
		mRedLight = mSceneMgr->createLight("RedFlyingLight");
		mRedLight->setType(Light::LT_POINT);
		mRedLight->setPosition(redLightPosition);
		mRedLight->setDiffuseColour(ColourValue::Black);
		mShipNode->attachLight(mRedLight);

		// Blue light, in "off" state
		mBlueLight = mSceneMgr->createLight("BlueFlyingLight");
		mBlueLight->setType(Light::LT_POINT);
		mBlueLight->setPosition(blueLightPosition);
		mBlueLight->setDiffuseColour(ColourValue::Black);
		mShipNode->attachLight(mBlueLight);

		// White light in "off" state
		mWhiteLight = mSceneMgr->createLight("WhiteFlyingLight");
		mWhiteLight->setType(Light::LT_POINT);
		mWhiteLight->setPosition(whiteLightPosition);
		mWhiteLight->setDiffuseColour(ColourValue::Black);
		mShipNode->attachLight(mWhiteLight);


		// Light flashers
		mRedLightFlasher = new LightFlasher(mRedLight, mRedLightBoard, ColourValue::Red);
		mBlueLightFlasher = new LightFlasher(mBlueLight, mBlueLightBoard, ColourValue::Blue);
		mWhiteLightFlasher = new LightBlinker(mWhiteLight, mWhiteLightBoard, ColourValue::White, ColourValue::Black, 0.975);

		// Light controller functions
		mRedLightControllerFunc = new LightFlasherControllerFunction(Ogre::WFT_SINE, 0.5, 0.0);
		mBlueLightControllerFunc = new LightFlasherControllerFunction(Ogre::WFT_SQUARE, 0.5, 0.5);
		mWhiteLightControllerFunc = new LightFlasherControllerFunction(Ogre::WFT_SAWTOOTH, 0.25, 0.0);

		// Light controllers
		ControllerManager* mControllerManager = &ControllerManager::getSingleton();
		mRedLightController = mControllerManager->createController(mControllerManager->getFrameTimeSource(), mRedLightFlasher, mRedLightControllerFunc);
		mBlueLightController = mControllerManager->createController(mControllerManager->getFrameTimeSource(), mBlueLightFlasher, mBlueLightControllerFunc);
		mWhiteLightController = mControllerManager->createController(mControllerManager->getFrameTimeSource(), mWhiteLightFlasher, mWhiteLightControllerFunc);

    }

	void createFrameListener(void)
    {
		// This is where we instantiate our own frame listener
        mFrameListener= new SpaceFrameListener(mWindow, mCamera, mShipNode);
        mRoot->addFrameListener(mFrameListener);

		// Create our second frame listener, to rotate the camera
		SpaceCameraRotator* cameraRotator = new SpaceCameraRotator(mWindow, mCamera, mShipNode, Vector3(0, 0, 100));
		mRoot->addFrameListener(cameraRotator);
    }

};
