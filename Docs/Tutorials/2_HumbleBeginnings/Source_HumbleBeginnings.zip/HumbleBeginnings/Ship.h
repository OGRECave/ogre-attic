
#ifndef __SHIP_H__

#define __SHIP_H__

#include "Ogre.h"
#include "SpaceObject.h"

using namespace Ogre;



class CShip: public FrameListener
{
public:
    // Constructor takes a RenderWindow because it uses that to determine input context
    CShip(RenderWindow* win, SceneManager* mSceneMgr);

    ~CShip();

    // Override frameStarted event to process that (don't care about frameEnded)
	bool frameStarted(const FrameEvent& evt);
protected:
    InputReader* mInputDevice;
    Camera* mCamera;
    RenderWindow* mWindow;
    bool mStatsOn;

	// Scene nodes for the various ship pieces
	SceneNode* mBodyNode;	
	SceneNode* mAfterburnNode;
	SceneNode* mCannonsNode;

	// Entities
	Entity* mEntity;

	// Particle systems
	ParticleSystem* pSysCannons;

	// Flight information
	Real mHTilt;
	Real mHTiltPending;
	Real mVTilt;
	Real mVTiltPending;

	// Quaternion default orientation
	Quaternion* mDefaultOrientation;

	void BeginFly(void);
	void FlyUp(Real FlyFactor, Real TimeScale);
	void FlyDown(Real FlyFactor, Real TimeScale);
	void FlyLeft(Real FlyFactor, Real TimeScale);
	void FlyRight(Real FlyFactor, Real TimeScale);
	void EndFly(void);

	void CannonsOn(void);
	void CannonsOff(void);
};




#endif