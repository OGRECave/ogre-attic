/*
-----------------------------------------------------------------------------
This source file is part of OGRE
    (Object-oriented Graphics Rendering Engine)
For the latest info, see http://www.stevestreeting.com/ogre/

Copyright � 2000-2001 Steven J. Streeting
Also see acknowledgements in Readme.html

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA, or go to
http://www.gnu.org/copyleft/gpl.html.
-----------------------------------------------------------------------------
*/
/*
-----------------------------------------------------------------------------
Filename:    ParticleApplication.cpp
Description: Specialisation of OGRE's framework application to show the
             environment mapping feature.
-----------------------------------------------------------------------------
*/


#include "ExampleApplication.h"
#include "Ship.h"

// Event handler to add ability to alter curvature
class ShooterFrameListener : public ExampleFrameListener
{
protected:
	CShip* mShip;
	BillboardSet* stuff;
	Billboard* stuffboard;
	SceneNode* stuffNode;
	bool colourup;
	ColourValue currentcolour;

public:
    ShooterFrameListener(RenderWindow* win, Camera* cam, CShip* ship, BillboardSet* astuff,
							Billboard* astuffboard, SceneNode* astuffNode) : ExampleFrameListener(win, cam)
    {
		mShip = ship;
		stuff = astuff;
		stuffboard = astuffboard;
		stuffNode = astuffNode;
		colourup = false;
    }

    bool frameStarted(const FrameEvent& evt)
    {

/*		mShip->BeginFly();

		if(mInputDevice->isKeyDown(Ogre::KC_UP))
		  mShip->FlyUp(80.0, evt.timeSinceLastFrame);

		if(mInputDevice->isKeyDown(Ogre::KC_DOWN))
		  mShip->FlyDown(80.0, evt.timeSinceLastFrame);

		if(mInputDevice->isKeyDown(Ogre::KC_LEFT))
		  mShip->FlyLeft(80.0, evt.timeSinceLastFrame);

		if(mInputDevice->isKeyDown(Ogre::KC_RIGHT))
		  mShip->FlyRight(80.0, evt.timeSinceLastFrame);
		

		mShip->EndFly();

		if(mInputDevice->isKeyDown(Ogre::KC_SPACE))
		{
			mShip->CannonsOn();
		} else {
			mShip->CannonsOff();
		};
*/

		// do some colour stuff
		currentcolour = stuffboard->getColour();
		if(colourup)
		{
			Real diff = 0.1 * evt.timeSinceLastFrame;
			currentcolour.r = currentcolour.r + diff;
			currentcolour.g = currentcolour.g + diff;
			currentcolour.b = currentcolour.b + diff;

			if(currentcolour.r > 1.0)
			{
				currentcolour.r = 1.0;
				currentcolour.g = 1.0;
				currentcolour.b = 1.0;
				colourup = false;
			};
			
		} else {
			Real diff = 0.1 * evt.timeSinceLastFrame;
			currentcolour.r = currentcolour.r - diff;
			currentcolour.g = currentcolour.g - diff;
			currentcolour.b = currentcolour.b - diff;

			if(currentcolour.r < 0.0)
			{
				currentcolour.r = 0.0;
				currentcolour.g = 0.0;
				currentcolour.b = 0.0;
				colourup = true;
			};

		};
		stuffboard->setColour(currentcolour);

/*
		if(mInputDevice->isKeyDown(Ogre::KC_L))
		{
			ColourValue cv(1.0, 1.0, 1.0);
			stuffboard->setColour(cv);
		} else {
			ColourValue cv(0.2, 0.2, 0.2);
			stuffboard->setColour(cv);
		};
*/

        // Call default
        return ExampleFrameListener::frameStarted(evt);

    }
};



class ShooterApplication : public ExampleApplication
{
public:
    ShooterApplication() {}

protected:
	CShip* mShip;
	BillboardSet* stuff;
	Billboard* stuffboard;
	SceneNode* stuffNode;

    // Just override the mandatory create scene method
    void createScene(void)
    {
        // Set ambient light
        mSceneMgr->setAmbientLight(ColourValue(0.5, 0.5, 0.5));
       
//        Entity *ent1 = mSceneMgr->createEntity("razor", "razor.oof");    

		mShip = new CShip(mWindow, mSceneMgr);
		mRoot->addFrameListener(mShip);

       // Create a skybox
        mSceneMgr->setSkyBox(true, "Examples/SpaceSkyBox");



		stuff = mSceneMgr->createBillboardSet("stuff");
		stuff->setMaterialName("Examples/Flare");
		stuffboard = stuff->createBillboard(0.0, 0.0, 0.0);

		stuffNode = mSceneMgr->getRootSceneNode()->createChild();
		stuffNode->attachObject(stuff);

/*		mShipNode = mSceneMgr->getRootSceneNode()->createChild();
		mShipNode->yaw(180.0);
		mShipNode->translate(0.0, -160.0, 40.0);
		mShipNode->attachObject(ent1);

		mAfterburnNode = mShipNode->createChild();
		mAfterburnNode->translate(0.0, 0.0, -20.0);
		//mAfterburnNode->rotate(Vector3::UNIT_X, -180.0);

		ParticleSystem* pSysVapour = ParticleSystemManager::getSingleton().createSystem("EngineVapour", "Examples/EngineVapour");
		mAfterburnNode->attachObject(pSysVapour);


		mCannonsNode = mShipNode->createChild();
		mCannonsNode->translate(0.0, 0.0, 40.0);
		//mAfterburnNode->rotate(Vector3::UNIT_X, -180.0);

		pSysCannons = ParticleSystemManager::getSingleton().createSystem("EngineVapour", "Examples/LaserFire");
		mCannonsNode->attachObject(pSysCannons);


        // Green nimbus around Ogre
/*        ParticleSystem* pSys1 = ParticleSystemManager::getSingleton().createSystem("Nimbus", 
            "Examples/GreenyNimbus");
  //      mSceneMgr->getRootSceneNode()->createChild()->attachObject(pSys1);
*/

        // Create shared node for 2 fountains
  //      mFountainNode = mSceneMgr->getRootSceneNode()->createChild();

        // fountain 1
/*        ParticleSystem* pSys2 = ParticleSystemManager::getSingleton().createSystem("fountain1", 
            "Examples/PurpleFountain");
        // Point the fountain at an angle
        SceneNode* fNode = mFountainNode->createChild();
        fNode->translate(200,-100,0);
        fNode->rotate(Vector3::UNIT_Z, 20);
        fNode->attachObject(pSys2);
*/
        // fountain 2
/*        ParticleSystem* pSys3 = ParticleSystemManager::getSingleton().createSystem("fountain2", 
            "Examples/PurpleFountain");
        // Point the fountain at an angle
        fNode = mFountainNode->createChild();
        fNode->translate(-200,-100,0);
        fNode->rotate(Vector3::UNIT_Z, -20);
        fNode->attachObject(pSys3);
*/

        // Create a rainstorm 
/*        ParticleSystem* pSys4 = ParticleSystemManager::getSingleton().createSystem("rain", 
            "Examples/Rain");
        SceneNode* rNode = mSceneMgr->getRootSceneNode()->createChild();
        rNode->translate(0,1000,0);
  //      rNode->attachObject(pSys4);
        // Fast-forward the rain so it looks more natural
        pSys4->fastForward(5);
*/
    }

    // Create new frame listener
    void createFrameListener(void)
    {
        mFrameListener= new ShooterFrameListener(mWindow, mCamera, mShip, stuff, stuffboard, stuffNode);
        mRoot->addFrameListener(mFrameListener);
		mCamera->rotate(Vector3::UNIT_X, -5.0);
    }


};

