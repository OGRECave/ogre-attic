#include "Ship.h"

#define SHIP_RETURN_RATE 1
#define SHIP_MAX_TILT 15.0


CShip::CShip(RenderWindow* win, SceneManager* mSceneMgr)
{
    mInputDevice = PlatformManager::getSingleton().createInputReader();
    mInputDevice->initialise(win,true, true);
    mWindow = win;
    mStatsOn = false;

	mHTilt = 0.0;
	mVTilt = 0.0;

	mEntity = mSceneMgr->createEntity("razor", "razor.oof");

	mBodyNode = mSceneMgr->getRootSceneNode()->createChild();
	mBodyNode->yaw(180.0);
	mBodyNode->translate(0.0, -160.0, 40.0);
	mBodyNode->attachObject(mEntity);

	mCannonsNode = mBodyNode->createChild();
	mCannonsNode->translate(0.0, 0.0, 40.0);

	//pSysCannons = ParticleSystemManager::getSingleton().createSystem("EngineVapour", "Examples/LaserFire");
	//mCannonsNode->attachObject(pSysCannons);

	mDefaultOrientation = new Quaternion(mBodyNode->getOrientation());



}


CShip::~CShip()
{
	delete mDefaultOrientation;
    PlatformManager::getSingleton().destroyInputReader(mInputDevice);
}




bool CShip::frameStarted(const FrameEvent& evt)
{
	mInputDevice->capture();

	BeginFly();

	if(mInputDevice->isKeyDown(Ogre::KC_UP))
		FlyUp(80.0, evt.timeSinceLastFrame);

	if(mInputDevice->isKeyDown(Ogre::KC_DOWN))
		FlyDown(80.0, evt.timeSinceLastFrame);

	if(mInputDevice->isKeyDown(Ogre::KC_LEFT))
		FlyLeft(80.0, evt.timeSinceLastFrame);

	if(mInputDevice->isKeyDown(Ogre::KC_RIGHT))
		FlyRight(80.0, evt.timeSinceLastFrame);
		

	EndFly();

	if(mInputDevice->isKeyDown(Ogre::KC_SPACE))
	{
		CannonsOn();
	} else {
		CannonsOff();
	};

	return true;
}




void CShip::BeginFly(void)
{
	mHTiltPending = 0.0;
	mVTiltPending = 0.0;
}



void CShip::FlyUp(Real FlyFactor, Real TimeScale)
{
	mVTiltPending = FlyFactor * TimeScale;

	Real MoveFactor = FlyFactor * TimeScale;
	mBodyNode->translate(0.0, MoveFactor, 0.0);
}


void CShip::FlyDown(Real FlyFactor, Real TimeScale)
{
	mVTiltPending = -FlyFactor * TimeScale;

	Real MoveFactor = FlyFactor * TimeScale;
	mBodyNode->translate(0.0, -MoveFactor, 0.0);
}


void CShip::FlyLeft(Real FlyFactor, Real TimeScale)
{
	mHTiltPending = FlyFactor * TimeScale;

	Real MoveFactor = FlyFactor * TimeScale;
	mBodyNode->translate(-MoveFactor, 0.0, 0.0);
}


void CShip::FlyRight(Real FlyFactor, Real TimeScale)
{
	mHTiltPending = -FlyFactor * TimeScale;

	Real MoveFactor = FlyFactor * TimeScale;
	mBodyNode->translate(MoveFactor, 0.0, 0.0);
}


void CShip::EndFly(void)
{
	if(mHTiltPending != 0.0)
	{
		// Calculate the tilt change
		Real Change = 0.0;
		Real MaxChange = 0.0;
		if (mHTiltPending > 0.0)
		{
			MaxChange = (SHIP_MAX_TILT - mHTiltPending) / 2.0;
			if(MaxChange > mHTiltPending)
			{
				Change = mHTiltPending;
			} else {
				Change = MaxChange;
			};
		}
		if (mHTiltPending < 0.0)
		{
			MaxChange = (-SHIP_MAX_TILT + mHTiltPending) / 2.0;
			if(MaxChange < mHTiltPending)
			{
				Change = mHTiltPending;
			} else {
				Change = MaxChange;
			};

		}
			
			
		// Apply the pending tilt
		mHTilt += Change; 
		
		// Don't let the horizontal tilt go too far left or right
		if (mHTilt > SHIP_MAX_TILT)
			mHTilt = SHIP_MAX_TILT;
		if (mHTilt < -SHIP_MAX_TILT)
			mHTilt = -SHIP_MAX_TILT;
	} else {
		// Return tilt towards zero 
		if(mHTilt > 0)
		{
			mHTilt -= SHIP_RETURN_RATE;
			if(mHTilt < 0.0)
				mHTilt = 0.0;
		};
		
		if(mHTilt < 0)
		{
			mHTilt += SHIP_RETURN_RATE;
			if(mHTilt > 0)
				mHTilt = 0.0;
		};
	}

	if(mVTiltPending != 0.0)
	{
		// Apply the pending tilt
		mVTilt += mVTiltPending; 
		
		// Don't let the horizontal tilt go too far left or right
		if (mVTilt > SHIP_MAX_TILT)
			mVTilt = SHIP_MAX_TILT;
		if (mVTilt < -SHIP_MAX_TILT)
			mVTilt = -SHIP_MAX_TILT;
	} else {
		// Return tilt towards zero 
		if(mVTilt > 0)
		{
			mVTilt -= SHIP_RETURN_RATE;
			if(mVTilt < 0.0)
				mVTilt = 0.0;
		};
		
		if(mVTilt < 0)
		{
			mVTilt += SHIP_RETURN_RATE;
			if(mVTilt > 0)
				mVTilt = 0.0;
		};
	}

	// Set the ship orientation
	mBodyNode->setOrientation(*mDefaultOrientation);
	mBodyNode->rotate(Vector3::UNIT_Y, mHTilt);
	mBodyNode->rotate(Vector3::UNIT_X, mVTilt);

}


void CShip::CannonsOn(void)
{
	//pSysCannons->getEmitter(0)->setEmissionRate(100);
}


void CShip::CannonsOff(void)
{
	//pSysCannons->getEmitter(0)->setEmissionRate(0);
}
