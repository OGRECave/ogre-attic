#ifndef __SPACEOBJECT_H__
#define __SPACEOBJECT_H__

#include "Ogre.h"

using namespace Ogre;

class CSpaceObject 
{
private:
protected:
	SceneManager* mSceneMgr;
	SceneNode* mMainNode;
	CSpaceObject(SceneManager* SceneMgr);	
public:
	~CSpaceObject(void);
};




#endif