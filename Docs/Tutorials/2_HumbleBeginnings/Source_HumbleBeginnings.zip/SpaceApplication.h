
#include "ExampleApplication.h"


class SpaceFrameListener : public ExampleFrameListener
{
protected:
	SceneNode* mShipNode;

public:
    SpaceFrameListener(RenderWindow* win, Camera* cam, SceneNode* shipNode) : ExampleFrameListener(win, cam)
    {
		mShipNode = shipNode;
    };

    bool frameStarted(const FrameEvent& evt)
    {
		// Move upto 80 units/second
		Real MoveFactor = 80.0 * evt.timeSinceLastFrame;

		// Copy the current state of the input devices
		mInputDevice->capture();

		// Move the ship node!
		if(mInputDevice->isKeyDown(Ogre::KC_UP))
		  mShipNode->translate(0.0, MoveFactor, 0.0);

		if(mInputDevice->isKeyDown(Ogre::KC_DOWN))
		  mShipNode->translate(0.0, -MoveFactor, 0.0);

		if(mInputDevice->isKeyDown(Ogre::KC_LEFT))
		  mShipNode->translate(-MoveFactor, 0.0, 0.0);

		if(mInputDevice->isKeyDown(Ogre::KC_RIGHT))
		  mShipNode->translate(MoveFactor, 0.0, 0.0);

		return true;
    }

};



class SpaceApplication : public ExampleApplication
{
protected:
    Entity* mShip;
	SceneNode* mShipNode;

	void createScene(void)
    {
		// Set a low level of ambient lighting so we can see the ship
		mSceneMgr->setAmbientLight(ColourValue(0.5, 0.5, 0.5));

        // Use the "Space" skybox
        mSceneMgr->setSkyBox(true, "Examples/SpaceSkyBox");

		// Load "Razor", our space ship
		mShip = mSceneMgr->createEntity("razor", "razor.mesh");

		// Create a Scene Node and attach our ship to it
		mShipNode = static_cast<SceneNode*>(mSceneMgr->getRootSceneNode()->createChild());
		mShipNode->attachObject(mShip);

    }

	void createFrameListener(void)
    {
		// This is where we instantiate our own frame listener
        mFrameListener= new SpaceFrameListener(mWindow, mCamera, mShipNode);
        mRoot->addFrameListener(mFrameListener);
    }

};
