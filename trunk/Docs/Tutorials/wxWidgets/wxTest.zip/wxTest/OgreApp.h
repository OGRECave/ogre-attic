#ifndef OGREAPP_H
#define OGREAPP_H

// Includes //
#include <Ogre.h>
#include <OgreD3D9RenderWindow.h>
#include <OgreD3D9RenderSystem.h> 

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

using namespace Ogre;

// The OGRE test application class. //
class OgreApp
{
private:
	Root *mRoot;
	RenderSystem *mRSys;
	RenderWindow *mWnd;
	SceneManager *mScene;

	Camera *mCam;
	Viewport *mView;

	bool mReady;

public:
	OgreApp();
	~OgreApp();

	void Resize(long w, long h);
	void Update();
	void Init(HWND handle);

	void Tick(Real t);

	void RotateView(Real yaw, Real pitch);
	void MoveView(Real x, Real y, Real z);
};

#endif