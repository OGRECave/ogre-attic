// Includes //
#include <wx/wx.h>
#include <wx/msgdlg.h>
#include "OgreApp.h"

// Namespace //
using namespace Ogre;

// Constructor //
OgreApp::OgreApp()
{
	mRoot = 0;
	mReady = false;
}

// Destructor //
OgreApp::~OgreApp()
{
	// Kill root
	if(mRoot)
		delete mRoot;
}

// Init //
void OgreApp::Init(HWND handle)
{
	// Make the root
	mRoot = new Root();

	try
	{
		// Set parameters of render system (window size, etc.)
		mRoot->restoreConfig();

		// Render system.
		mRSys = mRoot->getRenderSystem();
		D3D9RenderSystem *rsys = (D3D9RenderSystem *)mRSys;
		rsys->SetExternalWindowHandle(handle);

		// Root and Scene.
		mWnd = mRoot->initialise(true);
		mScene = mRoot->getSceneManager(ST_GENERIC);

		// Lights.
		mScene->setAmbientLight(ColourValue(0.2f, 0.2f, 0.2f, 1.0f));
		
		Light *mainLight = mScene->createLight("Main Light");
		mainLight->setType(Light::LT_POINT);
		mainLight->setPosition(-100, 100, 300);

		Light *fillerLight = mScene->createLight("Filler Light");
		fillerLight->setType(Light::LT_POINT);
		fillerLight->setPosition(100, -100, -300);
		fillerLight->setDiffuseColour(0.5f, 0.5f, 0.5f);

		// Resources.
		mRoot->addResourceLocation("../Media", "FileSystem");
		MaterialManager::getSingleton().parseAllSources();

		ResourceManager::addCommonSearchPath("../Media");
		ResourceManager::addCommonArchiveEx("../Media/cubemapsJS.zip", "Zip");

		// Skybox.
		mScene->setSkyBox(true, "My/SkyBox");

		// Ninja.
		Entity *ninjaEntity = mScene->createEntity("Ninja Boy", "ninja.mesh");
		ninjaEntity->getAnimationState("Walk")->setEnabled(true);
		SceneNode *ninjaNode = static_cast<SceneNode *>(mScene->getRootSceneNode()->createChild());
		ninjaNode->attachObject(ninjaEntity);

		// Camera.
		mCam = mScene->createCamera("Main Camera");
		mCam->setPosition(0, 0, 300);
		mCam->lookAt(0, 0, 0);

		// Viewports.
		mView = mWnd->addViewport(mCam);
		mView->setBackgroundColour(ColourValue(0.25f, 0.1f, 0.1f, 1.0f));

		// All set up, activate.
		mWnd->setActive(true);
		
		// Ready now.
		mReady = true;
	}
	catch(Ogre::Exception &e)
	{
		String s = "OgreApp::Init() - Exception:\n" + e.getFullDescription() + "\n";
		LogManager::getSingleton().logMessage(s, LML_CRITICAL);
		wxMessageBox(e.getFullDescription().c_str(), "Exception!", wxICON_EXCLAMATION);

		// Clean up.
		if(mRoot)
			delete mRoot;
	}
}

// Resize //
void OgreApp::Resize(long w, long h)
{
//	mWnd->resize(w, h);

	D3D9RenderWindow *wnd = (D3D9RenderWindow *)mWnd;

	wnd->setReady(false);
	wnd->WindowMovedOrResized();
	wnd->setReady(true);
}

// Update //
void OgreApp::Update()
{
	if(mReady)
	{
		mRoot->renderOneFrame();
	}
}

// Timer ticks //
void OgreApp::Tick(Real t)
{
	// Tell the Ninja.
	mScene->getEntity("Ninja Boy")->getAnimationState("Walk")->addTime(t);
}

// Rotates the view //
void OgreApp::RotateView(Real yaw, Real pitch)
{
	mCam->yaw(yaw * (mCam->getFOVy() / mCam->getAspectRatio() / 320.0f));
	mCam->pitch(pitch * (mCam->getFOVy() / 240.0f));
}

// Moves the view //
void OgreApp::MoveView(Real x, Real y, Real z)
{
	mCam->moveRelative(Vector3(x, y, z));
}