// Includes //
#include <wx/wx.h>
#include "wxTest.h"

#include <Ogre.h>
#include "OgreApp.h"

// IDs for Controls and Menu Commands //
enum
{
	wxTest_Quit = 1,
	wxTest_About = wxID_ABOUT,
	wxTest_Timer
};

// Event Table //
BEGIN_EVENT_TABLE(wxTestFrame, wxFrame)
	EVT_MENU(wxTest_Quit, wxTestFrame::OnQuit)
	EVT_MENU(wxTest_About, wxTestFrame::OnAbout)

	EVT_TIMER(wxTest_Timer, wxTestFrame::OnTimer)
	EVT_PAINT(wxTestFrame::OnPaint)
	EVT_SIZE(wxTestFrame::OnSize)

	EVT_MOUSE_EVENTS(wxTestFrame::OnMouse)
END_EVENT_TABLE()

// Platform specific crap that creates the application, etc. //
IMPLEMENT_APP(wxTestApplication);

// Function definitions //
// App Init
bool wxTestApplication::OnInit()
{
	// Make the frame
	mFrame = new wxTestFrame(_T("wxWidgets/OGRE Integration Demo"), wxPoint(100, 100), wxSize(640, 480));

	// Show it as the top window
	mFrame->Show(TRUE);
	SetTopWindow(mFrame);

	// Make an OGRE application object.
	mOgreApp = new OgreApp();

	// Initialize with the window handle.
	HWND h = (HWND)(mFrame->GetHandle());
	mOgreApp->Init(h);

	// Tell the frame about its OGRE app.
	mFrame->SetOgreApp(mOgreApp);

	// Update!
	mOgreApp->Update();

	// All clear!
	return TRUE;
}

// App Exit
int wxTestApplication::OnExit()
{
	// Kill OGRE app.
	delete mOgreApp;

	// All done here.
	return 0;
}

// Frame Constructor
wxTestFrame::wxTestFrame(const wxChar *title,
						 wxPoint &pos,
						 wxSize &size) 
						: wxFrame((wxFrame *)NULL,
						-1,
						title,
						pos,
						size)
{
	// No Ogre app until it's given to us.
	mOgreAppPtr = 0;

	// Menu
	wxMenu *menuFile = new wxMenu();
	menuFile->Append(wxTest_Quit, _T("E&xit:\tAlt-X"), "Exit this program.");

	wxMenu *menuHelp = new wxMenu();
	menuHelp->Append(wxTest_About, _T("&About...\tF1"), "About this program.");

	wxMenuBar *menuBar = new wxMenuBar();
	menuBar->Append(menuFile, _T("&File"));
	menuBar->Append(menuHelp, _T("&Help"));
	SetMenuBar(menuBar);

	// Status Bar
	CreateStatusBar(2);
	SetStatusText("Es Funktioniert.");

	// Kick off the timer.
	mTimer = new wxTimer(this, wxTest_Timer);
	mTimer->Start(10);
}

// Frame Destructor
wxTestFrame::~wxTestFrame()
{
	delete mTimer;
}

// On Quit
void wxTestFrame::OnQuit(wxCommandEvent &WXUNUSED(e))
{
	Close(TRUE);
}

// On About
void wxTestFrame::OnAbout(wxCommandEvent &WXUNUSED(e))
{
    wxString msg;
    msg.Printf( _T("This is the About dialog of the wxWidgets/OGRE Integration Demo.\n")
				_T("This code may be distributed, used and modified freely,\n")
				_T("as long as credit is always given to the original author:\n")
                _T("Dieter Buys (June 2004)"));

    wxMessageBox(msg, _T("About wxWidgets/OGRE Integration Demo"), wxOK | wxICON_INFORMATION, this);
}

// On Resize
void wxTestFrame::OnSize(wxSizeEvent &e)
{
	wxSize s = this->GetClientSize();
	
	if(mOgreAppPtr)
		mOgreAppPtr->Resize(s.GetWidth(), s.GetHeight());
}

// On Paint
void wxTestFrame::OnPaint(wxPaintEvent &WXUNUSED(e))
{
	// Make DC (for no reason).
	wxPaintDC dc(this);

	// Tell OGRE to redraw.
	if(mOgreAppPtr)
		mOgreAppPtr->Update();
}

// On Mouse
void wxTestFrame::OnMouse(wxMouseEvent &e)
{
	// Camera controls
	if(e.Dragging() && mOgreAppPtr)
	{
		// Compute deltas
		long	delta_x = e.m_x - mMouseX,
				delta_y = e.m_y - mMouseY;

		// Dolly, orient or pan?
		if(e.m_leftDown && e.m_rightDown)
			mOgreAppPtr->MoveView(0.0f, 0.0f, delta_y);
		else if(e.m_leftDown)
			mOgreAppPtr->RotateView(delta_x*2, delta_y);
		else if(e.m_rightDown)
			mOgreAppPtr->MoveView((Real)(-delta_x), (Real)delta_y, 0.0f);
	}

	// Save mouse position (for computing deltas for dragging)
	mMouseX = e.m_x;
	mMouseY = e.m_y;

	// Tell OGRE to redraw.
	if(mOgreAppPtr)
		mOgreAppPtr->Update();
}

// Timer tick
void wxTestFrame::OnTimer(wxTimerEvent &e)
{
	if(mOgreAppPtr)
	{
		// Updates animations, etc.
		mOgreAppPtr->Tick(e.GetInterval() / 1000.0f);

		// Update the display
		mOgreAppPtr->Update();
	}
}