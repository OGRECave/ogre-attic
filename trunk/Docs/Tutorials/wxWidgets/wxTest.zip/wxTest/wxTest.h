#ifndef WXTEST_H
#define WXTEST_H

#include <wx/timer.h>
#include "OgreApp.h"

// wxTestFrame class declaration //
class wxTestFrame : public wxFrame
{
private:
	DECLARE_EVENT_TABLE()

	wxTimer *mTimer;
	
	OgreApp *mOgreAppPtr;

	long mMouseX, mMouseY;

public:
	wxTestFrame(const wxChar *title, wxPoint &pos, wxSize &size);
	~wxTestFrame();
	
	void SetOgreApp(OgreApp *a) { mOgreAppPtr = a; }

	void OnQuit(wxCommandEvent &e);
	void OnAbout(wxCommandEvent &e);		
	void OnSize(wxSizeEvent &e);
	void OnPaint(wxPaintEvent &e);
	void OnMouse(wxMouseEvent &e);
	void OnTimer(wxTimerEvent &e);
};

// wxTestApplication class declaration //
class wxTestApplication : public wxApp
{
private:
	OgreApp *mOgreApp;
	wxTestFrame *mFrame;

public:
	virtual bool OnInit();
	virtual int OnExit();
};
#endif